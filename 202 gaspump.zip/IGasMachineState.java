/**
 * Write a description of class IGasMachineState here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface  IGasMachineState  
{
  
   public  void enter_pin(GasPumpWorld obj);
   public String getMessage();
}
